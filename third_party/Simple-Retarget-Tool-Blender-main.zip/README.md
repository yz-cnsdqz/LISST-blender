# Simple-Retarget-Tool-Blender
A simple armature retargeting tool for Blender

Haoliang's modification:
1. Added retarget LISST to Mixamo

Update V3:
1. Rest pose can be used with blend shapes.

Update V2:
1. Set Rest Pose to easily apply rest pose.
2. Preset Import/Export.
# Tutorial
v2 : https://youtu.be/qnJFOSisDLQ

v1: https://youtu.be/dnTH1iMDh8E

### Found my work useful? It would be awesome to buy me a coffee. Thanks & Enojy! :)

<a href="https://www.buymeacoffee.com/fahadp" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>
